import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

const primarycolor = Color(0xffFFD200);
const graycolor = Color(0xff838383);
const kwhite = Colors.white;
const kblack = Colors.black;
